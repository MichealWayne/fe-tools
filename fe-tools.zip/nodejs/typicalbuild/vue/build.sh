# build prod

echo "build build!"

npm run build && exec /bin/bash