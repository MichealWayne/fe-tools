# build prod

echo "build prod!"

npm run build:prod && exec /bin/bash