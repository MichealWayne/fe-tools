<template>
    <section>
        <router-view/>
    </section>
</template>

<script>
    export default {
        name: "App"
    }
</script>

<style lang="less">

</style>