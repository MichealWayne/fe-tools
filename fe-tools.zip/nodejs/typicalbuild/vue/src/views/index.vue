<template>
    <section>
        <p class='f-tc'>hello vue</p>
    </section>
</template>

<script>
    export default {
        name: "index"
    }
</script>

<style lang="less">

</style>