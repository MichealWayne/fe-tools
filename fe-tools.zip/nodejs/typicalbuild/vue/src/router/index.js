import Index from '@/views/index';

export default {
    routes: [{
        path: '/',
        name: '/',
        component: Index
    }]
}