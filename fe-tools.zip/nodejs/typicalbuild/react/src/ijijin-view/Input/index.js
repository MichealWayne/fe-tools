import Input from './input.tsx'

export default Input