/*
 * Icon
 * 图标
 */

import Icon from './icon.tsx'
import './index.less'

export default Icon;