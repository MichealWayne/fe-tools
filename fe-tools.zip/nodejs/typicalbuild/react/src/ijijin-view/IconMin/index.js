/*
 * Icon
 * 图标
 */

import Icon from './icon.js'
import './index.less'

export default Icon;