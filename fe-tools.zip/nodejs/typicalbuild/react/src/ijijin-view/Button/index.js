import Button from './button.tsx'
import '../less/Button.less'

export default Button