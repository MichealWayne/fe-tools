/**
 * /src/js/index/enter.js -> index.html
 */

import 'ijijin_builder/stylebuild/lib/mobile.less';