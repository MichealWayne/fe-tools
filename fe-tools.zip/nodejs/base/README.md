# base 方法
@(前端)[nodejs|web]

利用node构建项目的简易方法库。

-**文件操作**：建立文件、文件夹；组件拆分css、js文件；
-**控制台输出样式**：可调整控制台输出文案的背景、颜色；
-**功能函数**： 常用功能函数集合如时间格式化

-----------

## 1.fsFuncs.js FS文件操作
- travelFolderSync()：遍历文件夹；
- mkdirsSync()：同步创建目录；
- rmdirsSync()：同步删除指定目录下的所前目录和文件,包括当前目录；
- fsExistsSync()：查看文件或文件夹是否存在；
- setFile()：查看文件，如果不存在则新建一个；

## Tip控制台输出

## process控制

## server简易服务器

