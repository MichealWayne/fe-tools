## image build

依赖于gm、imageMagick

## 图片转base64字符串

## 图片转webp字符串

## 生成移动端1x/2x/webp图片并替换html中模糊图占位