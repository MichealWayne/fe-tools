import { htmlString } from '../../../types/types.js';
import { YafHTMLElement } from '../../index.js';
export declare class YafContentMarked extends YafHTMLElement<htmlString | undefined> {
    onConnect(): void;
}
