import { JSONOutput } from 'typedoc';
import { YafHTMLElement } from '../../../index.js';
export declare class YafSignatureConditional extends YafHTMLElement<JSONOutput.ConditionalType> {
    onConnect(): void;
}
