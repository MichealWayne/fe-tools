import { JSONOutput } from 'typedoc';
import { YafHTMLElement } from '../../../index.js';
export declare class YafSignatureNamedTupleMember extends YafHTMLElement<JSONOutput.NamedTupleMemberType> {
    onConnect(): void;
}
