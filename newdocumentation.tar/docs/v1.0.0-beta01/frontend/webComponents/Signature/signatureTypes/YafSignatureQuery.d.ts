import { JSONOutput } from 'typedoc';
import { YafHTMLElement } from '../../../index.js';
export declare class YafSignatureQuery extends YafHTMLElement<JSONOutput.QueryType> {
    onConnect(): void;
}
