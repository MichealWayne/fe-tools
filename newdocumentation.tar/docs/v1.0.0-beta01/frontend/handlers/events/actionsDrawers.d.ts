export declare const resetDrawerHeight: () => Event;
export interface drawers {
    resetDrawerHeight: null;
}
